using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WolfHealth : MonoBehaviour {
    [SerializeField] int maxHealth;
    float health;

    //void Awake() {
    //    health = maxHealth;
    //}
}
