using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[System.Serializable]
public struct RoomData {
    public int leftx, rightx, y;

}
public class CameraRoomData : MonoBehaviour
{
    public List<RoomData> rooms;

    void Start()
    {
        
    }


    void Update()
    {
        
    }
}
